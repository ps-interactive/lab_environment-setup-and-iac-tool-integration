#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
SSH_DIR="$PROJECT_ROOT/ssh_keys"

echo "==> Generating SSH key pair..."
mkdir -p "$SSH_DIR"
if [ ! -f "$SSH_DIR/id_rsa" ]; then
    ssh-keygen -t rsa -b 4096 -f "$SSH_DIR/id_rsa" -N "" -C "ansible-docker"
fi
chmod 600 "$SSH_DIR/id_rsa"
chmod 644 "$SSH_DIR/id_rsa.pub"

echo "==> Initialising Terraform..."
cd "$PROJECT_ROOT/terraform"
terraform init

echo "==> Applying Terraform..."
terraform apply -auto-approve

echo "==> Making inventory script executable..."
chmod +x "$PROJECT_ROOT/ansible/inventory/terraform_inventory.py"

echo "==> Waiting for SSH to become available..."
PORT=$(terraform output -raw ssh_port)
for i in $(seq 1 20); do
    if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=2 \
           -i "$SSH_DIR/id_rsa" -p "$PORT" ansible@127.0.0.1 true 2>/dev/null; then
        echo "SSH is up."
        break
    fi
    echo "Waiting... ($i/20)"
    sleep 2
done

echo "==> Running Ansible playbook..."
cd "$PROJECT_ROOT/ansible"
ansible-playbook playbooks/setup.yml -v

echo ""
echo "Done! To SSH manually:"
echo "  ssh -i ssh_keys/id_rsa -p $PORT ansible@127.0.0.1"
