#!/bin/bash
set -e

# Install the public key passed in via environment variable
if [ -n "$SSH_PUBLIC_KEY" ]; then
    echo "$SSH_PUBLIC_KEY" > /home/ansible/.ssh/authorized_keys
    chmod 600 /home/ansible/.ssh/authorized_keys
    chown ansible:ansible /home/ansible/.ssh/authorized_keys
fi

# Generate host keys if not present (fresh container)
ssh-keygen -A

exec /usr/sbin/sshd -D
