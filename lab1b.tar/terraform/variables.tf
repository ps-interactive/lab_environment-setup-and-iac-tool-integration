variable "container_name" {
  description = "Name of the Docker container"
  type        = string
  default     = "ansible-target"
}

variable "ssh_public_key_path" {
  description = "Path to the SSH public key to inject into the container"
  type        = string
  default     = "../ssh_keys/id_rsa.pub"
}

variable "host_ssh_port" {
  description = "Host port mapped to container SSH port 22"
  type        = number
  default     = 2222
}
