terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

provider "docker" {}

# Build a custom image with sshd + Python (required for Ansible)
resource "docker_image" "ansible_target" {
  name = "ansible-target:latest"
  build {
    context    = "${path.module}/docker"
    dockerfile = "Dockerfile"
  }
  triggers = {
    dockerfile_hash = filemd5("${path.module}/docker/Dockerfile")
  }
}

resource "docker_container" "target" {
  name  = var.container_name
  image = docker_image.ansible_target.image_id

  # Expose SSH on a host port
  ports {
    internal = 22
    external = var.host_ssh_port
  }

  # Pass the public key as an environment variable; the entrypoint will install it
  env = [
    "SSH_PUBLIC_KEY=${trimspace(file(var.ssh_public_key_path))}"
  ]

  must_run = true
  restart  = "unless-stopped"
}
