output "container_id" {
  value = docker_container.target.id
}

output "container_name" {
  value = docker_container.target.name
}

output "ssh_host" {
  value = "127.0.0.1"
}

output "ssh_port" {
  value = var.host_ssh_port
}

output "ssh_user" {
  value = "ansible"
}
