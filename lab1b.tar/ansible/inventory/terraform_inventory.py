#!/usr/bin/env python3
"""
Dynamic inventory script that reads Terraform outputs.
Usage:
  ./terraform_inventory.py --list
  ./terraform_inventory.py --host <hostname>
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

TERRAFORM_DIR = Path(__file__).resolve().parents[2] / "terraform"


def get_terraform_outputs() -> dict:
    result = subprocess.run(
        ["terraform", "output", "-json"],
        cwd=TERRAFORM_DIR,
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(result.stdout)


def build_inventory(outputs: dict) -> dict:
    host = outputs["ssh_host"]["value"]
    port = outputs["ssh_port"]["value"]
    user = outputs["ssh_user"]["value"]
    name = outputs["container_name"]["value"]

    return {
        "docker_containers": {
            "hosts": [name],
        },
        "_meta": {
            "hostvars": {
                name: {
                    "ansible_host": host,
                    "ansible_port": port,
                    "ansible_user": user,
                    "ansible_ssh_private_key_file": str(
                        Path(__file__).resolve().parents[2] / "ssh_keys" / "id_rsa"
                    ),
                }
            }
        },
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--list", action="store_true")
    group.add_argument("--host", type=str)
    args = parser.parse_args()

    try:
        outputs = get_terraform_outputs()
    except subprocess.CalledProcessError as e:
        # Return empty inventory if Terraform hasn't been applied yet
        print(json.dumps({"_meta": {"hostvars": {}}}))
        sys.exit(0)

    if args.list:
        print(json.dumps(build_inventory(outputs), indent=2))
    elif args.host:
        inventory = build_inventory(outputs)
        hostvars = inventory["_meta"]["hostvars"]
        print(json.dumps(hostvars.get(args.host, {}), indent=2))


if __name__ == "__main__":
    main()
